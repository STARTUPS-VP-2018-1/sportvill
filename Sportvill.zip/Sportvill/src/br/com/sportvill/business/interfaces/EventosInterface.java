package br.com.sportvill.business.interfaces;
import br.com.sportvill.dominio.Eventos;


public interface EventosInterface {
    
    public Eventos salvarEventos (Eventos eventos);
    public Eventos buscarEventos (Integer id);
    
    
    
    
}
