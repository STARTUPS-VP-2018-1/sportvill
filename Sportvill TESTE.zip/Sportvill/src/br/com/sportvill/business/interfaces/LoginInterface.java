/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.sportvill.business.interfaces;

import br.com.sportvill.dominio.Cliente;

/**
 *
 * @author internet
 */
public interface LoginInterface {
    
    public boolean validarCliente(String usuario,String senha);
    
    public boolean validarClientePorObjeto(Cliente cliente);

    
}
