/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.sportvill.business;

import br.com.sportvill.business.interfaces.LoginInterface;
import br.com.sportvill.dominio.Cliente;

/**
 *
 * @author internet
 */
public class LoginBusiness implements LoginInterface{

    @Override
    public boolean validarCliente(String usuario, String senha) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public boolean validarClientePorObjeto(Cliente cliente){
        
        return false;
    }
    
}
