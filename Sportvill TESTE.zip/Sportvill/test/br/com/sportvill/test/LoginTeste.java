package br.com.sportvill.test;

import br.com.sportvill.business.ClienteBusiness;
import br.com.sportvill.business.LoginBusiness;
import br.com.sportvill.business.LoginFaceBookBusiness;
import br.com.sportvill.business.interfaces.ClienteInterface;
import br.com.sportvill.business.interfaces.LoginInterface;


public class LoginTeste {
    
    public static void main(String[] args) {
        
        String usuario = "joao";
        String senha = "123";
        
        LoginInterface loginBusiness = new LoginFaceBookBusiness();
        
        if(loginBusiness.validarCliente(usuario,senha)){
            System.out.println("Usuario Valida!");
        }else{
            System.out.println("Usuario não existen");
        }
    }
    
}
